The online Supplementary Materials have two items. 

1. Data and R Codes: Data and R Codes used for each application and simulation studies presented in this paper are available at \texttt{https://github.com/caojiguo/FNN}; this includes some of the source for the \textbf{FuncNN} R package. A README file is included which describes the files. (FNN\_Code.zip)

2. Supplemental Document: Document containing the proof for Corollary 1, tables with descriptions of various parameters, and additional application and simulation results. (supplementalFNN.pdf)
